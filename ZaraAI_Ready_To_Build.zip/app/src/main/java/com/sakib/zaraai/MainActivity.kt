package com.sakib.zaraai

import android.app.Activity
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.RecognitionListener
import android.speech.tts.TextToSpeech
import android.content.Intent
import android.widget.*
import android.view.ViewGroup
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private lateinit var output: TextView
    private lateinit var input: EditText
    private var recognizer: SpeechRecognizer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 24)
            layoutParams = ViewGroup.LayoutParams(-1, -1)
        }
        root.addView(TextView(this).apply { text = "Zara AI"; textSize = 30f })
        root.addView(TextView(this).apply { text = "Owner: Sakib"; textSize = 16f })
        output = TextView(this).apply { text = "Namaste! Main Zara hoon. Aap kaise hain?"; textSize = 18f; setPadding(0, 28, 0, 18) }
        root.addView(output)
        input = EditText(this).apply { hint = "Yahan likhein..." }
        root.addView(input)
        root.addView(Button(this).apply {
            text = "Send"
            setOnClickListener { respond(input.text.toString()) }
        })
        root.addView(Button(this).apply {
            text = "Speak"
            setOnClickListener { listen() }
        })
        setContentView(root)
    }

    private fun respond(message: String) {
        if (message.isBlank()) return
        val answer = when {
            message.contains("hello", true) || message.contains("hi", true) || message.contains("namaste", true) -> "Namaste! Main Zara AI hoon."
            message.contains("naam", true) -> "Mera naam Zara AI hai."
            else -> "Aapne kaha: $message. Abhi main starter demo mode mein hoon."
        }
        output.text = answer
        if (::tts.isInitialized) tts.speak(answer, TextToSpeech.QUEUE_FLUSH, null, "zara_reply")
    }

    private fun listen() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            output.text = "Is device par speech recognition available nahi hai."
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) { output.text = "Voice recognition error: $error" }
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                input.setText(text)
                respond(text)
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
        }
        recognizer?.startListening(intent)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts.language = Locale("hi", "IN")
    }

    override fun onDestroy() {
        recognizer?.destroy()
        if (::tts.isInitialized) tts.shutdown()
        super.onDestroy()
    }
}
