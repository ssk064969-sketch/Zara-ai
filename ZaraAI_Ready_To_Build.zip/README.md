# Zara AI — Owner Sakib (starter build)

This repository contains a minimal Android starter app branded **Zara AI** and a GitHub Actions workflow that builds a debug APK.

## Build on GitHub
1. Put the **contents** of this ZIP in the root of a GitHub repository (including the hidden `.github` folder).
2. Commit the files to the `main` branch.
3. Open the repository's **Actions** tab and select **Build Zara AI APK**. A push to `main` also starts a build automatically.
4. When the run finishes, download the `Zara-AI-debug-APK` artifact. It contains `app-debug.apk`.

## Included in this starter
- Zara AI app label and Owner: Sakib
- Basic text chat demo
- Android Hindi speech recognition button (requires an available speech-recognition service; microphone permission handling may need device-specific follow-up)
- Android text-to-speech (voice depends on the installed Android TTS engine)

## Important limitations
This is **not** the complete 38-feature assistant. It does not currently include Gemini/API integration, wake-word listening, WhatsApp or call automation, screen control, vision, cloud memory, or the other advanced integrations. Those require further implementation, permissions, service configuration, and real-device testing.

The workflow builds a **debug APK**. It does not sign a production release APK.
